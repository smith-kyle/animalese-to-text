16kHz - Duplicates removed - Mono

for i in *.wav; do ffmpeg -i "$i" -ac 1 -ar 16000 "../new_wavs/${i%.*}.wav"; done && cd .. && mv new_wavs wavs